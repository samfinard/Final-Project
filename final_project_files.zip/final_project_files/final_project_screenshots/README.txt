README


process_windowing shows main process window with windowing

process_bootstrapping shows main process window with bootstrapping instead of windowing

pearson_corr is pearson correlation between columns in master csv




Each folder has the pictures of a specific model (based on the name of folder)

Inside the folder, the image with the name of the model shows the settings for the model

The image named data shows the dataset with the additional data column for predictions.

The image named performance shows the root mean squared error and squared error for the model.

The image named graph shows a graph of the Dow Jones percent change values and the values our model predicted for the Dow Jones percent change values.

The image named graph_stack is the same graph as above with stacking applied.